export const PORT = process.env.PORT || 5000;

export const mongoDBURL =
  process.env.MONGO_URI || "mongodb://127.0.0.1:27017/fitnesstrack";
